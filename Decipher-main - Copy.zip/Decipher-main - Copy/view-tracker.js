// Magazine View Tracker
class MagazineViewTracker {
    constructor() {
        this.viewData = null;
        this.dataFile = 'magazine-views.json';
        this.init();
    }

    async init() {
        await this.loadViewData();
    }

    async loadViewData() {
        try {
            const response = await fetch(this.dataFile);
            if (response.ok) {
                this.viewData = await response.json();
            } else {
                // Initialize with default data if file doesn't exist
                this.viewData = {
                    views: {
                        "Jan-March 2025": 0,
                        "April-June 2025": 0,
                        "Jan-June 2024": 0,
                        "July-Sept 2024": 0,
                        "Oct-Dec 2024": 0
                    },
                    lastUpdated: new Date().toISOString()
                };
            }
        } catch (error) {
            console.error('Error loading view data:', error);
            // Fallback to default data
            this.viewData = {
                views: {
                    "Jan-March 2025": 0,
                    "April-June 2025": 0,
                    "Jan-June 2024": 0,
                    "July-Sept 2024": 0,
                    "Oct-Dec 2024": 0
                },
                lastUpdated: new Date().toISOString()
            };
        }
    }

    async incrementView(magazineName) {
        if (!this.viewData) {
            await this.loadViewData();
        }

        if (this.viewData.views[magazineName] !== undefined) {
            this.viewData.views[magazineName]++;
            this.viewData.lastUpdated = new Date().toISOString();
            
            // Save to localStorage as backup
            localStorage.setItem('magazineViews', JSON.stringify(this.viewData));
            
            // Try to save to server (this would need a backend in production)
            await this.saveViewData();
        }
    }

    async saveViewData() {
        try {
            // In a real application, this would be a POST request to a backend
            // For now, we'll just use localStorage
            localStorage.setItem('magazineViews', JSON.stringify(this.viewData));
        } catch (error) {
            console.error('Error saving view data:', error);
        }
    }

    getTopMagazines(count = 4) {
        if (!this.viewData) {
            return [];
        }

        // Convert views object to array and sort by view count
        const magazines = Object.entries(this.viewData.views)
            .map(([name, views]) => ({ name, views }))
            .sort((a, b) => b.views - a.views)
            .slice(0, count);

        return magazines;
    }

    getViewCount(magazineName) {
        return this.viewData ? this.viewData.views[magazineName] || 0 : 0;
    }

    // Load from localStorage if available
    loadFromLocalStorage() {
        try {
            const stored = localStorage.getItem('magazineViews');
            if (stored) {
                this.viewData = JSON.parse(stored);
            }
        } catch (error) {
            console.error('Error loading from localStorage:', error);
        }
    }
}

// Global instance
window.magazineTracker = new MagazineViewTracker();
