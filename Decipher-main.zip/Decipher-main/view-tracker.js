// Magazine View Tracker
class MagazineViewTracker {
    constructor() {
        this.viewData = null;
        this.dataFile = 'magazine-views.json';
        this.firestore = null;
        this.collection = 'magazines';
        this.functions = null;
        this.init();
    }

    async init() {
        // Load any locally stored counts first (persisted per device)
        this.loadFromLocalStorage();
        // Then load baseline from JSON and merge (favor higher counts)
        await this.loadViewData();
        // Initialize Firebase if available
        this.initFirebase();
        // If Firestore is ready, hydrate from Firestore as the source of truth
        if (this.firestore) {
            await this.syncFromFirestore();
        }
    }

    initFirebase() {
        try {
            if (window.__FIREBASE_CONFIG__ && window.firebase && window.firebase.apps) {
                if (!window.firebase.apps.length) {
                    window.firebase.initializeApp(window.__FIREBASE_CONFIG__);
                }
                this.firestore = window.firebase.firestore();
                this.functions = window.firebase.functions();
            }
        } catch (e) {
            console.warn('Firebase not initialized:', e);
        }
    }

    async loadViewData() {
        try {
            const response = await fetch(this.dataFile);
            if (response.ok) {
                const fileData = await response.json();
                // If we already have local data, merge by taking the max per magazine
                if (this.viewData && this.viewData.views) {
                    const merged = { views: {}, lastUpdated: new Date().toISOString() };
                    const allKeys = new Set([
                        ...Object.keys(fileData.views || {}),
                        ...Object.keys(this.viewData.views || {})
                    ]);
                    allKeys.forEach((k) => {
                        const fileCount = (fileData.views || {})[k] || 0;
                        const localCount = (this.viewData.views || {})[k] || 0;
                        merged.views[k] = Math.max(fileCount, localCount);
                    });
                    this.viewData = merged;
                } else {
                    this.viewData = fileData;
                }
            } else {
                // Initialize with default data if file doesn't exist
                this.viewData = {
                    views: {
                        "Jan-March 2025": 0,
                        "April-June 2025": 0,
                        "Jan-June 2024": 0,
                        "July-Sept 2024": 0,
                        "Oct-Dec 2024": 0
                    },
                    lastUpdated: new Date().toISOString()
                };
            }
        } catch (error) {
            console.error('Error loading view data:', error);
            // Fallback to default data
            this.viewData = {
                views: {
                    "Jan-March 2025": 0,
                    "April-June 2025": 0,
                    "Jan-June 2024": 0,
                    "July-Sept 2024": 0,
                    "Oct-Dec 2024": 0
                },
                lastUpdated: new Date().toISOString()
            };
        }
    }

    async incrementView(magazineName) {
        if (!this.viewData) {
            await this.loadViewData();
        }

        if (this.viewData.views[magazineName] !== undefined) {
            this.viewData.views[magazineName]++;
            this.viewData.lastUpdated = new Date().toISOString();
            
            //s Save to localStorage as backup
            localStorage.setItem('magazineViews', JSON.stringify(this.viewData));
            
            // Try to persist globally via Callable Function (production-safe)
            try {
                if (this.functions) {
                    const incrementView = this.functions.httpsCallable('incrementView');
                    await incrementView({ magazineName });
                } else if (this.firestore) {
                    // Fallback: direct Firestore write if functions not available
                    const ref = this.firestore.collection(this.collection).doc(magazineName);
                    await ref.set({
                        views: window.firebase.firestore.FieldValue.increment(1),
                        updatedAt: window.firebase.firestore.FieldValue.serverTimestamp()
                    }, { merge: true });
                }
            } catch (e) {
                console.warn('Failed to increment via Cloud Function/Firestore, falling back to local:', e);
                await this.saveViewData();
            }
        }
    }

    async saveViewData() {
        try {
            // In a real application, this would be a POST request to a backend
            // For now, we'll just use localStorage
            localStorage.setItem('magazineViews', JSON.stringify(this.viewData));
        } catch (error) {
            console.error('Error saving view data:', error);
        }
    }

    getTopMagazines(count = 4) {
        if (!this.viewData) {
            return [];
        }

        // Convert views object to array and sort by view count
        const magazines = Object.entries(this.viewData.views)
            .map(([name, views]) => ({ name, views }))
            .sort((a, b) => b.views - a.views)
            .slice(0, count);

        return magazines;
    }

    async syncFromFirestore() {
        try {
            const snapshot = await this.firestore.collection(this.collection).get();
            const merged = { views: { ...((this.viewData && this.viewData.views) || {}) }, lastUpdated: new Date().toISOString() };
            snapshot.forEach(doc => {
                const data = doc.data();
                if (typeof data.views === 'number') {
                    merged.views[doc.id] = Math.max(merged.views[doc.id] || 0, data.views);
                }
            });
            this.viewData = merged;
            localStorage.setItem('magazineViews', JSON.stringify(this.viewData));
        } catch (e) {
            console.warn('Failed to sync from Firestore:', e);
        }
    }

    getViewCount(magazineName) {
        return this.viewData ? this.viewData.views[magazineName] || 0 : 0;
    }

    // Load from localStorage if available
    loadFromLocalStorage() {
        try {
            const stored = localStorage.getItem('magazineViews');
            if (stored) {
                this.viewData = JSON.parse(stored);
            }
        } catch (error) {
            console.error('Error loading from localStorage:', error);
        }
    }
}

// Global instance
window.magazineTracker = new MagazineViewTracker();
