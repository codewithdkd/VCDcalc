// PDF Viewer JavaScript
class PDFViewer {
    constructor() {
        this.currentPage = 1;
        this.totalPages = 1;
        this.zoomLevel = 100;
        this.pdfUrl = '';
        this.isLoading = false;
        this.isOfficeEmbed = false;
        this.isGoogleViewer = false;
        
        this.initializeElements();
        this.bindEvents();
        this.setupSecurityFeatures();
        this.loadPDFFromURL();
    }

    initializeElements() {
        // Control elements
        this.zoomInBtn = document.getElementById('zoomIn');
        this.zoomOutBtn = document.getElementById('zoomOut');
        this.fitWidthBtn = document.getElementById('fitWidth');
        
        // Display elements
        this.currentPageSpan = document.getElementById('currentPage');
        this.totalPagesSpan = document.getElementById('totalPages');
        this.zoomLevelSpan = document.getElementById('zoomLevel');
        this.pdfFrame = document.getElementById('pdfFrame');
        
        // UI elements
        this.loadingIndicator = document.getElementById('loadingIndicator');
        this.errorMessage = document.getElementById('errorMessage');
        this.retryBtn = document.getElementById('retryBtn');
    }

    bindEvents() {
        // Zoom events
        this.zoomInBtn.addEventListener('click', () => this.zoomIn());
        this.zoomOutBtn.addEventListener('click', () => this.zoomOut());
        this.fitWidthBtn.addEventListener('click', () => this.fitToWidth());

        // Retry button
        this.retryBtn.addEventListener('click', () => this.loadPDFFromURL());

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));

        // PDF frame events
        this.pdfFrame.addEventListener('load', () => this.onPDFLoad());
        this.pdfFrame.addEventListener('error', () => this.onPDFError());

        // Mobile menu toggle
        const menuToggle = document.querySelector('.menu-toggle');
        if (menuToggle) {
            menuToggle.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggleMenu();
            });
            // Add touch events for mobile
            menuToggle.addEventListener('touchstart', (e) => {
                e.stopPropagation();
            });
            menuToggle.addEventListener('touchend', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggleMenu();
            });
        }

        // Ensure logo is clickable on mobile
        const logoLink = document.querySelector('.logo a');
        if (logoLink) {
            logoLink.addEventListener('touchstart', (e) => {
                e.stopPropagation();
            });
            logoLink.addEventListener('touchend', (e) => {
                e.stopPropagation();
            });
        }
    }

    setupSecurityFeatures() {
        // Disable right-click context menu (but allow navbar interactions)
        document.addEventListener('contextmenu', (e) => {
            // Allow navbar elements and PDF to work normally
            if (e.target.closest('.navbar') || e.target.closest('.menu-toggle') || e.target.closest('nav') || e.target.closest('#pdfFrame')) {
                return true;
            }
            e.preventDefault();
            return false;
        });

        // Enhanced security - prevent all possible ways to access content
        document.addEventListener('keydown', (e) => {
            // Prevent Ctrl+P (Print)
            if (e.ctrlKey && e.key === 'p') {
                e.preventDefault();
                return false;
            }
            
            // Prevent Ctrl+S (Save)
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                return false;
            }
            
            // Prevent Ctrl+Shift+I (Developer Tools)
            if (e.ctrlKey && e.shiftKey && e.key === 'I') {
                e.preventDefault();
                return false;
            }
            
            // Prevent F12 (Developer Tools)
            if (e.key === 'F12') {
                e.preventDefault();
                return false;
            }

            // Prevent Ctrl+Shift+C (Inspect Element)
            if (e.ctrlKey && e.shiftKey && e.key === 'C') {
                e.preventDefault();
                return false;
            }

            // Prevent Ctrl+U (View Source)
            if (e.ctrlKey && e.key === 'u') {
                e.preventDefault();
                return false;
            }

            // Prevent Ctrl+Shift+J (Console)
            if (e.ctrlKey && e.shiftKey && e.key === 'J') {
                e.preventDefault();
                return false;
            }

            // Prevent Print Screen
            if (e.key === 'PrintScreen') {
                e.preventDefault();
                return false;
            }
        });

        // Disable drag and drop (but allow navbar interactions)
        document.addEventListener('dragstart', (e) => {
            // Allow navbar elements to work normally
            if (e.target.closest('.navbar') || e.target.closest('.menu-toggle') || e.target.closest('nav')) {
                return true;
            }
            e.preventDefault();
            return false;
        });

        document.addEventListener('drop', (e) => {
            e.preventDefault();
            return false;
        });

        // Disable text selection (but allow navbar interactions)
        document.addEventListener('selectstart', (e) => {
            // Allow navbar elements to work normally
            if (e.target.closest('.navbar') || e.target.closest('.menu-toggle') || e.target.closest('nav')) {
                return true;
            }
            e.preventDefault();
            return false;
        });

        // Disable copy
        document.addEventListener('copy', (e) => {
            e.preventDefault();
            return false;
        });

        // Disable cut
        document.addEventListener('cut', (e) => {
            e.preventDefault();
            return false;
        });

        // Disable paste
        document.addEventListener('paste', (e) => {
            e.preventDefault();
            return false;
        });

        // Prevent iframe access
        if (window.self !== window.top) {
            window.top.location = window.self.location;
        }

        // Prevent iframe manipulation
        try {
            // Disable iframe access from parent
            if (window.parent && window.parent !== window) {
                window.parent.location = window.location;
            }
        } catch (e) {
            // If we can't access parent, that's good for security
        }



        // Disable viewport manipulation
        document.addEventListener('gesturestart', (e) => {
            // Allow navbar elements and PDF to work normally
            if (e.target.closest('.navbar') || e.target.closest('.menu-toggle') || e.target.closest('nav') || e.target.closest('#pdfFrame')) {
                return true;
            }
            e.preventDefault();
            return false;
        });

        // Disable touch context menu on mobile (but allow navbar and PDF interactions)
        document.addEventListener('touchstart', (e) => {
            // Allow navbar elements and PDF to work normally
            if (e.target.closest('.navbar') || e.target.closest('.menu-toggle') || e.target.closest('nav') || e.target.closest('#pdfFrame')) {
                return true;
            }
            e.preventDefault();
            return false;
        }, { passive: false });

        // Disable pinch zoom (but allow navbar interactions)
        document.addEventListener('gesturechange', (e) => {
            // Allow navbar elements and PDF to work normally
            if (e.target.closest('.navbar') || e.target.closest('.menu-toggle') || e.target.closest('nav') || e.target.closest('#pdfFrame')) {
                return true;
            }
            e.preventDefault();
            return false;
        });

        // Disable double tap zoom (but allow navbar interactions)
        let lastTouchEnd = 0;
        document.addEventListener('touchend', (e) => {
            // Allow navbar elements and PDF to work normally
            if (e.target.closest('.navbar') || e.target.closest('.menu-toggle') || e.target.closest('nav') || e.target.closest('#pdfFrame')) {
                return true;
            }
            const now = (new Date()).getTime();
            if (now - lastTouchEnd <= 300) {
                e.preventDefault();
                return false;
            }
            lastTouchEnd = now;
        }, false);

        // Additional security for PDF iframe
        if (this.pdfFrame) {
            this.pdfFrame.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                return false;
            });

            this.pdfFrame.addEventListener('selectstart', (e) => {
                e.preventDefault();
                return false;
            });

            this.pdfFrame.addEventListener('dragstart', (e) => {
                e.preventDefault();
                return false;
            });
        }
    }

    loadPDFFromURL() {
        // Get PDF URL from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        this.pdfUrl = urlParams.get('pdf') || '';
        
        if (!this.pdfUrl) {
            this.showError('No PDF URL provided. Please specify a PDF URL in the query parameter.');
            return;
        }

        this.showLoading();
        this.loadPDF();
    }

    loadPDF() {
        try {
            let embedUrl = this.pdfUrl;
            
            // Extract filename from URL for display
            this.updateFilename();
            
            // Prefer Office Online embed for OneDrive/1drv links to avoid Chrome PDF viewer
            if (this.pdfUrl.includes('1drv.ms') || this.pdfUrl.includes('onedrive.live.com')) {
                embedUrl = `https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(this.pdfUrl)}`;
                this.isOfficeEmbed = true;
                this.isGoogleViewer = false;
            } else {
                // For direct PDF URLs
                const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
                if (isMobile) {
                    // Use Google Docs Viewer on mobile so the PDF renders inline instead of new tab
                    embedUrl = `https://docs.google.com/gview?embedded=1&url=${encodeURIComponent(this.pdfUrl.split('#')[0])}`;
                    this.isGoogleViewer = true;
                    this.isOfficeEmbed = false;
                } else {
                    // Desktop: use native PDF viewer with hidden toolbar and internal zoom
                    const hasHash = this.pdfUrl.includes('#');
                    const pdfViewerParams = 'toolbar=0&navpanes=0&scrollbar=0';
                    embedUrl = this.pdfUrl.split('#')[0] + (hasHash ? '&' : '#') + pdfViewerParams + `&zoom=${this.zoomLevel}`;
                    this.isOfficeEmbed = false;
                    this.isGoogleViewer = false;
                }
            }
            this.pdfFrame.src = embedUrl;
            
        } catch (error) {
            console.error('Error loading PDF:', error);
            this.showError('Failed to load PDF. Please check the URL and try again.');
        }
    }

    onPDFLoad() {
        this.hideLoading();
        this.hideError();
        
        // Try to get total pages (this might not work with all PDF viewers)
        this.updatePageInfo();
        
        // Track PDF view
        this.trackPDFView();

        // For direct PDFs, set initial fit-to-width so content fills viewer
        if (!this.isOfficeEmbed && !this.isGoogleViewer) {
            this.setDirectPdfZoom('page-width');
            this.zoomLevelSpan.textContent = 'Fit';
        }
    }

    onPDFError() {
        this.hideLoading();
        this.showError('Failed to load PDF. Please check the URL and try again.');
    }

    trackPDFView() {
        // Try to determine magazine name from URL or filename
        if (window.magazineTracker && this.pdfUrl) {
            // Extract magazine name from URL or use filename
            let magazineName = this.getMagazineNameFromURL();
            if (magazineName) {
                window.magazineTracker.incrementView(magazineName);
                console.log(`Tracked PDF view for: ${magazineName}`);
            }
        }
    }

    getMagazineNameFromURL() {
        // Try to extract magazine name from URL parameters or referrer
        try {
            // Check if there's a referrer from release.html
            if (document.referrer && document.referrer.includes('release.html')) {
                // This is a bit tricky without server-side processing
                // For now, we'll use a simple mapping based on URL patterns
                return this.mapURLToMagazineName(this.pdfUrl);
            }
        } catch (error) {
            console.error('Error extracting magazine name:', error);
        }
        return null;
    }

    mapURLToMagazineName(url) {
        // Simple mapping - in a real app, this would be more sophisticated
        const urlLower = url.toLowerCase();
        
        if (urlLower.includes('jan-march') || urlLower.includes('janmarch')) {
            return 'Jan-March 2025';
        } else if (urlLower.includes('april-june') || urlLower.includes('apriljune')) {
            return 'April-June 2025';
        } else if (urlLower.includes('jan-june') || urlLower.includes('janjune')) {
            return 'Jan-June 2024';
        } else if (urlLower.includes('july-sept') || urlLower.includes('julysept')) {
            return 'July-Sept 2024';
        } else if (urlLower.includes('oct-dec') || urlLower.includes('octdec')) {
            return 'Oct-Dec 2024';
        }
        
        return null;
    }





    zoomIn() {
        if (this.zoomLevel < 200) {
            this.zoomLevel += 25;
            this.updateZoom();
        }
    }

    zoomOut() {
        if (this.zoomLevel > 50) {
            this.zoomLevel -= 25;
            this.updateZoom();
        }
    }

    fitToWidth() {
        // Use page-width for direct PDF; approximate with 100% for Office embed
        if (this.isOfficeEmbed) {
            this.zoomLevel = 100;
            this.updateZoom();
        } else {
            this.setDirectPdfZoom('page-width');
            // Keep a friendly display value
            this.zoomLevelSpan.textContent = 'Fit';
        }
    }

    updateZoom() {
        this.zoomLevelSpan.textContent = `${this.zoomLevel}%`;
        
        if (this.isOfficeEmbed || this.isGoogleViewer) {
            // Fallback: scale iframe for Office embed (no hash zoom support)
            this.pdfFrame.style.transform = `scale(${this.zoomLevel / 100})`;
            this.pdfFrame.style.transformOrigin = 'top left';
        } else {
            // Direct PDF: use viewer hash params to change internal zoom
            this.setDirectPdfZoom(this.zoomLevel);
            // Ensure no CSS transforms affect layout
            this.pdfFrame.style.transform = '';
        }
        
        // Update control states
        this.zoomInBtn.disabled = this.zoomLevel >= 200;
        this.zoomOutBtn.disabled = this.zoomLevel <= 50;
    }

    setDirectPdfZoom(zoomValue) {
        // Build a src with toolbar hidden and specified zoom
        try {
            const baseUrl = this.pdfUrl.split('#')[0];
            const hashParams = [`toolbar=0`, `navpanes=0`, `scrollbar=0`];
            if (zoomValue === 'page-width') {
                hashParams.push(`zoom=page-width`);
            } else {
                hashParams.push(`zoom=${zoomValue}`);
            }
            const newSrc = `${baseUrl}#${hashParams.join('&')}`;
            if (this.pdfFrame.src !== newSrc) {
                this.pdfFrame.src = newSrc;
            } else {
                // Force reload to apply zoom change if needed
                this.pdfFrame.contentWindow && this.pdfFrame.contentWindow.location && this.pdfFrame.contentWindow.location.replace(newSrc);
            }
        } catch (e) {
            // If cross-origin blocks replace, just set src again
            this.pdfFrame.src = `${this.pdfUrl.split('#')[0]}#toolbar=0&navpanes=0&scrollbar=0&zoom=${zoomValue === 'page-width' ? 'page-width' : zoomValue}`;
        }
    }

    updatePageInfo() {
        this.currentPageSpan.textContent = this.currentPage;
        this.totalPagesSpan.textContent = this.totalPages;
    }

    updateFilename() {
        try {
            let filename = 'Document';
            
            // Try to extract filename from URL
            if (this.pdfUrl) {
                // For OneDrive links, try to get a meaningful name
                if (this.pdfUrl.includes('1drv.ms') || this.pdfUrl.includes('onedrive.live.com')) {
                    // Use a generic name for OneDrive documents
                    filename = 'OneDrive Document';
                } else {
                    // Try to extract from URL path
                    const urlParts = this.pdfUrl.split('/');
                    const lastPart = urlParts[urlParts.length - 1];
                    if (lastPart && lastPart.includes('.')) {
                        filename = decodeURIComponent(lastPart);
                    }
                }
            }
            
            const filenameElement = document.getElementById('filenameDisplay');
            if (filenameElement) {
                const filenameText = filenameElement.querySelector('.filename-text');
                if (filenameText) {
                    filenameText.textContent = filename;
                }
            }
        } catch (error) {
            console.error('Error updating filename:', error);
        }
    }





    handleKeyboard(e) {
        // Navigation shortcuts
        switch(e.key) {
            case 'Home':
                e.preventDefault();
                this.currentPage = 1;
                this.updatePageInfo();
                break;
            case 'End':
                e.preventDefault();
                this.currentPage = this.totalPages;
                this.updatePageInfo();
                break;
            case '+':
            case '=':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.zoomIn();
                }
                break;
            case '-':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.zoomOut();
                }
                break;
            case '0':
                if (e.ctrlKey) {
                    e.preventDefault();
                    this.fitToWidth();
                }
                break;
        }
    }

    showLoading() {
        this.isLoading = true;
        this.loadingIndicator.style.display = 'block';
        this.errorMessage.style.display = 'none';
    }

    hideLoading() {
        this.isLoading = false;
        this.loadingIndicator.style.display = 'none';
    }

    showError(message) {
        this.errorMessage.style.display = 'block';
        this.loadingIndicator.style.display = 'none';
        
        const errorText = this.errorMessage.querySelector('p');
        if (errorText) {
            errorText.textContent = message;
        }
    }

    hideError() {
        this.errorMessage.style.display = 'none';
    }

    toggleMenu() {
        const nav = document.querySelector('nav');
        const menuToggle = document.querySelector('.menu-toggle');
        
        console.log('Toggle menu called'); // Debug log
        
        if (nav) {
            nav.classList.toggle('show');
            console.log('Nav show class toggled:', nav.classList.contains('show')); // Debug log
            
            // Update aria-expanded for accessibility
            const isExpanded = nav.classList.contains('show');
            if (menuToggle) {
                menuToggle.setAttribute('aria-expanded', isExpanded);
            }
        }
    }


}

// Global menu toggle function (backup)
function toggleMenu() {
    const nav = document.querySelector('nav');
    const menuToggle = document.querySelector('.menu-toggle');
    
    console.log('Global toggle menu called'); // Debug log
    
    if (nav) {
        nav.classList.toggle('show');
        console.log('Global nav show class toggled:', nav.classList.contains('show')); // Debug log
        
        // Update aria-expanded for accessibility
        const isExpanded = nav.classList.contains('show');
        if (menuToggle) {
            menuToggle.setAttribute('aria-expanded', isExpanded);
        }
    }
}

// Initialize PDF Viewer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PDFViewer();

    // Reveal footer only when user reaches bottom edge (desktop only)
    const footer = document.querySelector('.custom-footer');
    function revealFooter(show) {
        if (!footer) return;
        if (show) {
            footer.classList.add('footer-visible');
        } else {
            footer.classList.remove('footer-visible');
        }
    }

    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    if (!isMobile) {
        // Heuristic: if pointer is near bottom edge, show footer; else hide
        function onPointerMove(e) {
            const y = e.clientY || (e.touches && e.touches[0] && e.touches[0].clientY) || 0;
            const viewportH = window.innerHeight || document.documentElement.clientHeight;
            const threshold = 64; // px from bottom
            revealFooter(viewportH - y <= threshold);
        }

        window.addEventListener('mousemove', onPointerMove, { passive: true });
        window.addEventListener('touchmove', onPointerMove, { passive: true });
    } else {
        // Mobile: always visible via CSS; ensure class present for consistency
        revealFooter(true);
    }
});

// Close mobile menu when clicking outside
document.addEventListener('click', function(event) {
    const nav = document.querySelector('nav');
    const menuToggle = document.querySelector('.menu-toggle');
    
    if (!nav.contains(event.target) && !menuToggle.contains(event.target)) {
        nav.classList.remove('show');
        menuToggle.setAttribute('aria-expanded', 'false');
    }
});

// Close menu on escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const nav = document.querySelector('nav');
        const menuToggle = document.querySelector('.menu-toggle');
        
        nav.classList.remove('show');
        menuToggle.setAttribute('aria-expanded', 'false');
    }
});

// Prevent iframe from being accessed by parent window
if (window.self !== window.top) {
    window.top.location = window.self.location;
}

// Additional security - prevent embedding in other sites
try {
    if (window.parent && window.parent !== window) {
        window.parent.location = window.location;
    }
} catch (e) {
    // If we can't access parent, that's good for security
}

// Prevent page from being embedded
if (window.self !== window.top) {
    window.top.location = window.self.location;
}
